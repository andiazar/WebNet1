using Microsoft.EntityFrameworkCore;
using WebNet.model;
namespace WebNet.model
{
    public class CustomerDbContext: DbContext
    {
        public CustomerDbContext(DbContextOptions options)
            : base(options)
        {
        }

        public DbSet<Registro> Registros { get; set; }
    }
}