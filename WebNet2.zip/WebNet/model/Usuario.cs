using System.ComponentModel.DataAnnotations;
namespace WebNet.model
{
    public class Usuario
    {
         [Required(ErrorMessage = "Campo Requerido"), StringLength (20)]
         [Display(Name = "Nombre ")]
        public string Nombre { get; set; }

        [Required(ErrorMessage = "Campo Requerido"), StringLength (20)]
        public string Clave { get; set; }
        
        public string Mensaje { get; set; }
    }
}