# NetCore-MVC
 Project using netCore, front with Razor and session sistem 
